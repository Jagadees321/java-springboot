package com.org.inti;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class MyAppSecurityIntilizer extends AbstractSecurityWebApplicationInitializer {

}
